#!/bin/bash
./main_wrapper 0.0 0.136 0.2 128 64
