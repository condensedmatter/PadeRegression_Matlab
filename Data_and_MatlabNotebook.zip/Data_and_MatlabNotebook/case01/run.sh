#!/bin/bash
./main_wrapper 0.1 0.136 0.2 128 64
