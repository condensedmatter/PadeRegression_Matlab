addpath('/home/jian/Desktop/W6_PadeApproximationMatlab_GITHUB');
warning off;


k_limit=L1;

z=zeros(k_limit,50);

figure();
disp(k_limit);
for k=1:k_limit
    disp(k);
out=spectrum_k(k,L0,m_best,m_sig);
hold on;
plot(out,'.-');
legend(int2str(k));
z(k,:)=out;
end

legend(int2str([1:k_limit]'));
figure();
imagesc(z);


function output=spectrum_k(k,L0,m_best,m_sig)

x1=0;
x2=L0/2-1;

xPade=linspace(x1,x2,L0/2);

GPadeReal=m_best(1:L0/2,k);
sigReal=m_sig(1:L0/2,k)*0.613;

GPadeImag=zeros(1,L0/2);
sigImag=zeros(1,L0/2);

PadeReal=linspace(-L0,L0,100);
RR=300;
[rho_best,~]=errorTestControl_Data_function(xPade,GPadeReal,GPadeImag,sigReal,sigImag,PadeReal,RR);
output=abs(rho_best);
output=output(end/2+1:end);
end