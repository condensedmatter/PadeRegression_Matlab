clc;clear;

% M_best = dlmread('26_best.dat');
% M_error = dlmread('26_error.dat');
% L0=128;
% L1=64;

M_best = dlmread('best_09.txt');
M_error = dlmread('error_09.txt');
L0=32;
L1=1;

m_best = reshape(M_best,[L0,L1]);
m_error = reshape(M_error,[L0,L1]);


m_sig=m_error./m_best;
% m_sig is the relative error



disp('largest relative error is')
error_limit=max(max(abs(m_sig)));
disp(error_limit) ;
% imagesc(m_sig);
% colorbar();