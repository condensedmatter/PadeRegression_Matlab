addpath('/home/jian/Desktop/W6_PadeApproximationMatlab_GITHUB');

warning off;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  test data from know spectrum rho  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% xPade=[ 0.1:0.2:7  ];
% sig=0.0001;  
% GPadeReal=xPade;
% GPadeImag=xPade;
% sigReal=xPade;
% sigImag=xPade;
% N=size(xPade,1)*size(xPade,2);
% for i=1:N
%     [GPadeReal(i),GPadeImag(i)]=analyticSpectrumFunction( 0, xPade(i));
%     sigReal(i)=sig;
%     sigImag(i)=sig;
%     disp(i);
% end
% PadeReal=[-1:0.02:5];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  data from Monte Carlo simulation  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x1=0;
x2=L0/2-1;

xPade=linspace(x1,x2,L0/2);

k=1;
GPadeReal=m_best(1:L0/2,k);
sigReal=m_sig(1:L0/2,k)*0.5;

GPadeImag=zeros(1,L0/2);
sigImag=zeros(1,L0/2);

% PadeReal=linspace(-L0/20,L0/20,100);
PadeReal=horzcat(linspace(-2,-0.2,100),linspace(-0.2,0.2,100),linspace(0.2,2,100));
RR=100;

[rho_best,rho_error]=errorTestControl_Data_function(xPade,GPadeReal,GPadeImag,sigReal,sigImag,PadeReal,RR);


figure(7);
semilogy(PadeReal,-rho_best./PadeReal,'.-');
hold on;

figure(8);
plot(PadeReal,-rho_best./PadeReal,'.-');
hold on;


figure(9);
plot(PadeReal,-rho_best,'.-');
hold on;

% hold on;
% figure(8);
% errorbar(PadeReal,rho_best,rho_error,'-s','MarkerSize',10,...
%     'MarkerEdgeColor','red','MarkerFaceColor','red');
% xlabel(" real frequency \omega");

