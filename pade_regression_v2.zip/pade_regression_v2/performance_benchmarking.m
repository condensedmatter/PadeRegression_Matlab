clc;clear;



warning('off','all')
warning
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  data from Monte Carlo simulation  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  test data from know spectrum rho  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% construct the input
% analyticSpectrumFunction(a,b) takes two input 
% which is G(a+bi)

z=[ 0.1:0.1:7  ];
sig=0.0001;  
u_real=z;
u_imag=z;
err_u_real=z; %relative error
err_imag=z; %relative error
N=size(z,1)*size(z,2);
for i=1:N
    [u_real(i),u_imag(i)]=analyticGreenFunction( 0, z(i));
    err_u_real(i)=sig;
    err_imag(i)=sig;
end
x=[-1:0.02:5];

disp("assign complete")

%% run the analytic continuation function
[rho_best,rho_error]=PadeRegression(z,u_real,u_imag,err_u_real,err_imag,x,20000);

disp("regression complete")







%% plot the spectrum function with error bar
% figure(1);
% errorbar(x,rho_best,rho_error,'-s','MarkerSize',10,...
%     'MarkerEdgeColor','red','MarkerFaceColor','red');
% title({ "Pade Approximation Reconstruction of \rho(\omega)",[" with G_M(\omega_n) relative error = "+num2str(sig*100)+"%"]})
% xlabel(" real frequency \omega");

%% plot the recovered
% figure(2);
% cv=[0.75, 0, 0.75]
% plot(x,rho_best,'LineWidth',3,'color',cv)
% hold on;
% 
% 
% % add the original test function
% X=[-5:0.1:6];
% Y=X;
% for i=1:size(X,2)
%     Y(i)=aTestSpectrumFunction(X(i));
% end
%  plot(X,Y,'--','LineWidth',2,'color',cv);

%% plot the original function


% X=[-1:0.02:4];
% Y=X;
% for i=1:size(X,2)
%     Y(i)=aTestSpectrumFunction(X(i));
% end
%  plot(X,Y,'--','LineWidth',3);
%  %% font size
%  legend({'1%','0.1%','0.01%','0.001%','exact'},'FontSize',15,'color','white')
%  
%  axis([-1 4 -0.5 2.5])
% %  
% %  



%% with error  %%
 figure(5);
errorbar(x,rho_best,rho_error,'-s','MarkerSize',10,...
    'MarkerEdgeColor','red','MarkerFaceColor','red');
title({ "spectrum reconstruction , relative error = "+num2str(sig*100)+"%"},'FontSize',16);
xlabel(" real frequency \omega",'FontSize',15);
ylabel(" spectrum weight, arb. unit",'FontSize',15);
hold on;
X=[-1:0.1:5]
Y=X;
for i=1:size(X,2)
    Y(i)=aTestSpectrumFunction(X(i));
end
%   plot(X,Y,'--','LineWidth',2,'color','black');










%% plot the recovered
figure(8);
plot(x,rho_best,'LineWidth',1)
hold on;

 
%% plot the original function


X=[-1:0.02:5];
Y=X;
for i=1:size(X,2)
    Y(i)=aTestSpectrumFunction(X(i));
end
 plot(X,Y,'--','LineWidth',3);
 % font size
 legend({'1%','0.1%','0.01%','0.001%','exact'},'FontSize',15,'color','white')
 


%   xlabel(" real frequency \omega",'FontSize',15);
%  ylabel(" spectrum weight, arb. unit",'FontSize',15);
 %axis([-1 4 -0.5 2.5])
%  
%  








