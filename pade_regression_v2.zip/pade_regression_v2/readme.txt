VERSION-2018-12-11
PadeRegression.m is    contains the algorithm

performance_benchmarking.m     is the test script
aTestSpectrumFunction.m        contains many test spectra
analyticGreenFunction.m        generate the G(z)  from above test function


in case of Monte Carlo data,  there is no test function and G(z)
the procedure might be different.


version issue:
This is the compact version.


Other folders contain the generated graphs and older version files.
