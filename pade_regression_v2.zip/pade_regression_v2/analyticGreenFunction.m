% goal:
% this is the Complex to Complex map, analytic Green function

% input:
% a, b are real and imaginary part of z=a+bi

% ouput:
% outputRe,outputIm are the real and imaginary part of G(z)

% hidden parameters:
% testSpectrumFunction(.)  , the spectrum function
% x=[x_start: dx: x_end]   , the discretized integration steps

function [outputRe,outputIm]=analyticGreenFunction(a,b)

x=[-4.0:0.00005:6.00005];
y=x;
for i=1:size(x,1)*size(x,2)
    y(i)=aTestSpectrumFunction( x(i) );
end
integRe=x;
integIm=x;
for i=1:size(x,1)*size(x,2)
    integRe(i)= y(i)* (a-x(i))/((a-x(i))^2 + b^2 ) ;
    integIm(i)= y(i)* (-b )/((a-x(i))^2 + b^2 ) ;
end

outputRe=trapz(x,integRe);
outputIm=trapz(x,integIm);
end
