% goal:
% this is the Real to Real map, spectrum function

% input:
% x, a real number

% output:
% f, a real number (non-negative)

% hidden parameters:
% funcType, it is an int.   Change to different type of test functions.

function f=aTestSpectrumFunction(x)

funcType=3;


switch funcType
    %% square
    case 1
           if x<0.5
             f=0;
            elseif x<2.5
             f=1;
           else
             f=0;
           end
           
	%% triangle
    case 2
        if x<0
            f=0;
        elseif x<1
            f=x;
        elseif x<2
            f=2-x;
        else
            f=0;
        end
        
    %% double triangle
    case 3
        
        shift=0;
        x=x-shift;
        
        if x<0
            f=0;
        elseif x<1
            f=x;
        elseif x<1.5
            f=(2-x);
        elseif x<2.5
            f=x-1;
        elseif x<3
            f=9-3*x;
        else
            f=0;
        end
        
    %% Lorentz curve
    case 4
        x0=3;
        gamma=0.4;
        f=1/(pi*gamma*(1+((x-x0)/gamma)^2));

    %% hemisphere
    case 5
        R=1;
        x0=1.2 ;
        if x<x0-R
            f=0;
        elseif x<x0+R
            f=sqrt(R^2-(x-x0)^2);
        else
            f=0;
        end

    %% Gaussian curve
    case 6
        mu=2;
        sigma=0.1;
        f=exp(-0.5*((x-mu)/sigma)^2)/(sigma*sqrt(2*pi));


    %% two Lorentz curve
    case 7  
        x1=2;
        gamma1=0.05;

        x2=1;
        gamma2=0.1;

        f=1/(pi*gamma1*(1+((x-x1)/gamma1)^2))+1/(pi*gamma2*(1+((x-x2)/gamma2)^2));

        
    otherwise
        f=1.0;
end


end

