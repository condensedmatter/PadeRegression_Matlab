function u=testf(z)

u=1./z+rand(size(z))*0.001;

return 