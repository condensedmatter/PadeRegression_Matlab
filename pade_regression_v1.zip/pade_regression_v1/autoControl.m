clc;clear;

% test function is given [ADJUSTABLE]
% untitled10; % plot the \rho(\omega)
 
 
%%%%%%%%%%%%% analyticSpectrumFunction, modify the integrator
 
 
 % untitled4; % plot G(\omega+i \epsilon)
 % untitled5; % plot G(\omega_n);

 % input data points [ADJUSTABLE]is generated with analyticSpectrumFunction.m
 % integrator [ADJUSTABLE]
 % error is added
 untitled6; % find A,B using Pade fitting, and plot fitting input

 % untitled8;  % using Pade fitting to evalute \omega_n



%untitled13; % plot the zeros and poles of A/B 

untitled9; % using Pade fitting to evalute \omega